import bpy


class PROPS_PG_br_helper_loops(bpy.types.PropertyGroup):
    scn_name: bpy.props.StringProperty(
        name="scn_name",
        description="Scene name",
        default="",
    )
    all_frames: bpy.props.BoolProperty(
        name="all_frames",
        description="Render all available frames",
        default=True,
    )
    frame_start: bpy.props.IntProperty(
        name="frame_start",
        description="Render all available frames",
        default=1,
    )
    frame_end: bpy.props.IntProperty(
        name="frame_end",
        description="Render all available frames",
        default=250,
    )


class PROPS_PG_br_helper_fname(bpy.types.PropertyGroup):
    op_fname: bpy.props.StringProperty(
        name="op_fname",
        description="Part of output file name",
        default="",
    )
    eval_path: bpy.props.BoolProperty(
        name="eval_path",
        description="Evaluate as data path",
        default=False,
    )


class PROPS_PG_br_helper(bpy.types.PropertyGroup):
    op_dir: bpy.props.StringProperty(
        name="op_dir",
        description="Name of output directory",
        default="//",
        subtype='DIR_PATH',
    )
    fname_sep: bpy.props.StringProperty(
        name="fname_sep",
        description="Separator between name parts",
        default="-",
    )
    op_fname_parts: bpy.props.CollectionProperty(
        type=PROPS_PG_br_helper_fname
    )
    loops: bpy.props.CollectionProperty(
        type=PROPS_PG_br_helper_loops
    )


classes = [
    PROPS_PG_br_helper_fname,
    PROPS_PG_br_helper_loops,
    PROPS_PG_br_helper,
    ]


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.WindowManager.br_helper_pg = bpy.props.PointerProperty(
        type=PROPS_PG_br_helper)


def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)
    del bpy.types.WindowManager.br_helper_pg

if __name__ == "__main__":
    register()
