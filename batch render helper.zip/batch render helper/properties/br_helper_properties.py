import bpy


class PROPS_PG_br_helper_loops(bpy.types.PropertyGroup):
    # used for classic panel layout
    expand_loop_ctrl: bpy.props.BoolProperty(
        name="expand_loop_ctrl",
        description="Show/hide user selection",
        default=False,
    )
    scn_ptr: bpy.props.PointerProperty(
        type=bpy.types.Scene
    )


class PROPS_PG_br_helper_fname(bpy.types.PropertyGroup):
    op_fname: bpy.props.StringProperty(
        name="op_fname",
        description="Part of output file name",
        default="",
    )
    eval_path: bpy.props.BoolProperty(
        name="eval_path",
        description="Evaluate as data path",
        default=False,
    )
    # used for classic panel layout
    expand_eval: bpy.props.BoolProperty(
        name="expand_eval",
        description="Show/hide evaluation",
        default=False,
    )


class PROPS_PG_br_helper(bpy.types.PropertyGroup):
    op_dir: bpy.props.StringProperty(
        name="op_dir",
        description="Name of output directory",
        default="//",
        subtype='DIR_PATH',
    )
    fname_sep: bpy.props.StringProperty(
        name="fname_sep",
        description="Separator between name parts",
        default="-",
    )
    op_fname_parts: bpy.props.CollectionProperty(
        type=PROPS_PG_br_helper_fname
    )
    # used for ui_list layout
    act_fname_idx: bpy.props.IntProperty(
        name="act_fname_idx",
        description="Active Index",
        default=0,
        min=0,
    )
    loops: bpy.props.CollectionProperty(
        type=PROPS_PG_br_helper_loops
    )
    # used for ui_list layout
    act_scn_idx: bpy.props.IntProperty(
        name="act_scn_idx",
        description="Active Index",
        default=0,
        min=0,
    )
    frame_cnt_leading: bpy.props.IntProperty(
        name="frame_cnt_leading",
        description="# of leading 0's for frame count",
        default=4,
        min=0,
        soft_max=10,
    )
    op_fname_enum: bpy.props.EnumProperty(
        name="op_fname_enum",
        items=(
            ("bpy.path.basename(bpy.context.blend_data.filepath)", "file name", ""),
            ("bpy.context.scene.name", "scene name", ""),
            ("bpy.context.scene.camera.name", "active camera", ""),
            ("text", "text field", ""),
            ("bpy.context.object.name", "active object", ""),
            ("bpy.context.scene.frame_current", "current frame", ""),
        ),
        description="",
        default="text",
    )


classes = [
    PROPS_PG_br_helper_fname,
    PROPS_PG_br_helper_loops,
    PROPS_PG_br_helper,
    ]


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.WindowManager.br_helper_pg = bpy.props.PointerProperty(
        type=PROPS_PG_br_helper)
    # add current frame as default output file name part
    props = bpy.context.window_manager.br_helper_pg
    cur_items = [item.op_fname.split(sep='.')[-1] for item in props.op_fname_parts]
    if 'frame_current' not in cur_items:
        me = props.op_fname_parts.add()
        me.name = 'fname' + str(len(props.op_fname_parts)-1)
        me.op_fname = 'bpy.data.scenes["Scene"].frame_current'
        me.eval_path = True


def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)
    del bpy.types.WindowManager.br_helper_pg
