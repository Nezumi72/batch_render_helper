bl_info = {
    "name": "Batch Render Helper",
    "author": "Nezumi",
    "version": (0, 0, 7),
    "blender": (3, 6, 1),
    "location": "View3D > UI > BR Help",
    "description": "Assist with batch render file naming",
    "warning": "",
    "wiki_url": "",
    "category": "File",
}

import sys
import importlib
import os
import bpy


class FILE_PT_br_helper_prefs(bpy.types.AddonPreferences):
    bl_idname = __name__
    view_mode: bpy.props.EnumProperty(
        name="view_mode",
        items=(
            ("Classic", "Classic", "Classic"),
            ("UI_List", "UI_List", "UI_List"),
        ),
        description="Panel Layout View Mode",
        default="UI_List",
    )

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "view_mode", text="View Mode:")


addon_path = os.path.dirname(os.path.realpath(__file__))
modulesNames = []
folders = ['properties', 'operators', 'panels']
for folder in folders:
    for mod in os.listdir(os.path.join(addon_path, folder)):
        if mod.endswith('.py'):
            modulesNames.append(f"{folder}.{mod[:-3]}")

modulesFullNames = {}
for currentModuleName in modulesNames:
    if 'DEBUG_MODE' in sys.argv:
        modulesFullNames[currentModuleName] = ('{}'.format(currentModuleName))
    else:
        modulesFullNames[currentModuleName] = ('{}.{}'.format(__name__, currentModuleName))

for currentModuleFullName in modulesFullNames.values():
    if currentModuleFullName in sys.modules:
        importlib.reload(sys.modules[currentModuleFullName])
    else:
        globals()[currentModuleFullName] = importlib.import_module(currentModuleFullName)
        setattr(globals()[currentModuleFullName], 'modulesNames', modulesFullNames)


def register():
    bpy.utils.register_class(FILE_PT_br_helper_prefs)
    for currentModuleName in modulesFullNames.values():
        if currentModuleName in sys.modules:
            if hasattr(sys.modules[currentModuleName], 'register'):
                sys.modules[currentModuleName].register()


def unregister():
    bpy.utils.unregister_class(FILE_PT_br_helper_prefs)
    for currentModuleName in modulesFullNames.values():
        if currentModuleName in sys.modules:
            if hasattr(sys.modules[currentModuleName], 'unregister'):
                sys.modules[currentModuleName].unregister()
