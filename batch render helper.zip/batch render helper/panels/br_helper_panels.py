import bpy
from bl_ui.utils import PresetPanel


class FILE_PT_br_helper_presets(PresetPanel, bpy.types.Panel):
    bl_label = 'BR Helper Presets'
    preset_subdir = 'BR_Helper'
    preset_operator = 'script.execute_preset'
    preset_add_operator = 'br_helper.add_preset'


class FILE_PT_br_helper_main(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "BR Helper"
    bl_idname = "FILE_PT_br_helper_main"
    bl_label = "Batch Render Helper"

    def draw(self, context):
        props = context.window_manager.br_helper_pg
        layout = self.layout


class FILE_PT_br_helper_scns_classic(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "BR Helper"
    bl_idname = "FILE_PT_br_helper_scns_classic"
    bl_label = "Scene Controls"
    bl_parent_id = "FILE_PT_br_helper_main"

    @classmethod
    def poll(cls, context):
        props = context.window_manager.br_helper_pg
        prefs = bpy.context.preferences.addons["batch render helper"].preferences
        return prefs.view_mode == 'Classic'

    def draw(self, context):
        props = context.window_manager.br_helper_pg
        layout = self.layout
        box = layout.box()
        col = box.column(align=True)
        row = col.row()
        add_scn = row.operator("file.br_helper_scn_ops", text="Add Current Scene")
        add_scn.operation_type = "add_current"
        add_scn = row.operator("file.br_helper_scn_ops", text="Add All Scenes")
        add_scn.operation_type = "add_all"
        for i, details in enumerate(props.loops):
            box = layout.box()
            col = box.column(align=False)
            row = col.row(align=True)
            if details.expand_loop_ctrl:
                row.prop(details, 'expand_loop_ctrl', text='', icon='DOWNARROW_HLT')
            else:
                row.prop(details, 'expand_loop_ctrl', text='', icon='RIGHTARROW')
            row.label(text=details.scn_ptr.name)
            move = row.operator(
                'file.br_helper_scn_ops', text='', icon='TRIA_UP')
            move.idx = i
            move.operation_type = "move_up"
            move = row.operator(
                'file.br_helper_scn_ops', text='', icon='TRIA_DOWN')
            move.idx = i
            move.operation_type = "move_dn"
            del_item = row.operator(
                'file.br_helper_scn_ops', text='', icon='X')
            del_item.idx = i
            del_item.operation_type = "del_act"
            if details.expand_loop_ctrl:
                row = col.row()
                row.prop(details.scn_ptr, "frame_start", text="Start")
                row.prop(details.scn_ptr, "frame_end", text="End")
                row.prop(details.scn_ptr, "frame_step", text="Step")
                row = col.row()
                row.prop(details.scn_ptr.render, "resolution_x", text="Resolution X")
                row.prop(details.scn_ptr.render, "resolution_y", text="Resolution Y")
                row.prop(details.scn_ptr.render, "resolution_percentage", text="Resolution %")


class FILE_PT_br_helper_fout_classic(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "BR Helper"
    bl_idname = "FILE_PT_br_helper_fout_classic"
    bl_label = "Output File details"
    bl_parent_id = "FILE_PT_br_helper_main"

    @classmethod
    def poll(cls, context):
        props = context.window_manager.br_helper_pg
        prefs = bpy.context.preferences.addons["batch render helper"].preferences
        return prefs.view_mode == 'Classic'

    def draw_header_preset(self, _context):
        FILE_PT_br_helper_presets.draw_panel_header(self.layout)

    def draw(self, context):
        props = context.window_manager.br_helper_pg
        layout = self.layout
        box = layout.box()
        col = box.column(align=True)
        col.prop(props, "op_dir", text="Dir")
        col.prop(props, "fname_sep", text="Separator")
        col.prop(props, "frame_cnt_leading", text="Frame leading 0's")
        box = layout.box()
        col = box.column(align=True)
        row = col.row()
        row.prop(props, "op_fname_enum", text="")
        add_part = row.operator("file.br_helper_fname_ops", text="Add Item")
        add_part.item = props.op_fname_enum
        add_part.operation_type = "add_item"
        for i, details in enumerate(props.op_fname_parts):
            box = layout.box()
            col = box.column(align=True)
            row = col.row(align=True)
            if details.expand_eval:
                row.prop(details, 'expand_eval', text='', icon='DOWNARROW_HLT')
            else:
                row.prop(details, 'expand_eval', text='', icon='RIGHTARROW')
            row.prop(details, 'op_fname', text='')
            row.prop(details, 'eval_path', text='')
            move = row.operator(
                'file.br_helper_fname_ops', text='', icon='TRIA_UP')
            move.idx = i
            move.operation_type = "move_up"
            move = row.operator(
                'file.br_helper_fname_ops', text='', icon='TRIA_DOWN')
            move.idx = i
            move.operation_type = "move_dn"
            del_item = row.operator(
                'file.br_helper_fname_ops', text='', icon='X')
            del_item.idx = i
            del_item.operation_type = "del_act"
            me = ""
            if details.eval_path and details.op_fname:
                try:
                    me = f"{eval(details.op_fname)}"
                except NameError:
                    me = "< can not evaluate >"
                    details.eval_path = False
            elif details.eval_path and not details.op_fname:
                me = "< nothing to evaluate >"
            if details.expand_eval:
                col.label(text=me)


class FILE_UL_slots(bpy.types.UIList):

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname):
        slot = item
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            if slot:
                if active_propname == "act_scn_idx":
                    layout.prop(slot.scn_ptr, "name", text="", emboss=False)
                elif active_propname == "act_fname_idx":
                    layout.prop(slot, "op_fname", text="", emboss=False)
            else:
                layout.label(text="", translate=False)
        elif self.layout_type in {'GRID'}:
            layout.alignment = 'CENTER'
            layout.label(text="")


class FILE_PT_br_helper_scns_list(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "BR Helper"
    bl_idname = "FILE_PT_br_helper_scns_list"
    bl_label = "Scenes"
    bl_parent_id = "FILE_PT_br_helper_main"

    @classmethod
    def poll(cls, context):
        props = context.window_manager.br_helper_pg
        prefs = bpy.context.preferences.addons["batch render helper"].preferences
        return prefs.view_mode == 'UI_List'

    def draw(self, context):
        props = context.window_manager.br_helper_pg
        layout = self.layout
        row = layout.row()
        is_sortable = len(props.loops) > 1
        rows = 3
        if is_sortable:
            rows = 5
        row = layout.row()
        row.template_list("FILE_UL_slots", "", props, "loops", props, "act_scn_idx", rows=rows)
        col = row.column(align=True)
        add_scn = col.operator("file.br_helper_scn_ops", icon='ADD', text="")
        add_scn.operation_type = "add_current"
        add_all = col.operator("file.br_helper_scn_ops", icon='PRESET_NEW', text="")
        add_all.operation_type = "add_all"
        if props.loops:
            del_act = col.operator("file.br_helper_scn_ops", icon='REMOVE', text="")
            del_act.operation_type = "del_act"
            del_act.idx = props.act_scn_idx
        if is_sortable:
            col.separator()
            move_up = col.operator("file.br_helper_scn_ops", icon='TRIA_UP', text="")
            move_up.operation_type = "move_up"
            move_up.idx = props.act_scn_idx
            move_dn = col.operator("file.br_helper_scn_ops", icon='TRIA_DOWN', text="")
            move_dn.operation_type = "move_dn"
            move_dn.idx = props.act_scn_idx


class FILE_PT_br_helper_scn_sub_panel(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "BR Helper"
    bl_idname = "FILE_PT_br_helper_scn_sub_panel"
    bl_label = "Output Settings"
    bl_parent_id = "FILE_PT_br_helper_scns_list"

    @classmethod
    def poll(cls, context):
        props = context.window_manager.br_helper_pg
        prefs = bpy.context.preferences.addons["batch render helper"].preferences
        return prefs.view_mode == 'UI_List' and props.loops

    def draw(self, context):
        props = context.window_manager.br_helper_pg
        layout = self.layout
        col = layout.column(align=True)
        row = col.row(align=True)
        row.prop(props.loops[props.act_scn_idx].scn_ptr, "frame_start", text="Start")
        row.prop(props.loops[props.act_scn_idx].scn_ptr, "frame_end", text="End")
        row.prop(props.loops[props.act_scn_idx].scn_ptr, "frame_step", text="Step")
        row = col.row()
        row.prop(props.loops[props.act_scn_idx].scn_ptr.render, "resolution_x", text="Resolution X")
        row.prop(props.loops[props.act_scn_idx].scn_ptr.render, "resolution_y", text="Resolution Y")
        row.prop(props.loops[props.act_scn_idx].scn_ptr.render, "resolution_percentage", text="Resolution %")


class FILE_PT_br_helper_fout_list(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "BR Helper"
    bl_idname = "FILE_PT_br_helper_fout_list"
    bl_label = "Output Common Settings"
    bl_parent_id = "FILE_PT_br_helper_main"

    @classmethod
    def poll(cls, context):
        props = context.window_manager.br_helper_pg
        prefs = bpy.context.preferences.addons["batch render helper"].preferences
        return prefs.view_mode == 'UI_List'

    def draw(self, context):
        props = context.window_manager.br_helper_pg
        layout = self.layout
        box = layout.box()
        col = box.column(align=True)
        col.prop(props, "op_dir", text="Dir")
        col.prop(props, "fname_sep", text="Separator")
        col.prop(props, "frame_cnt_leading", text="Frame leading 0's")


class FILE_PT_br_helper_fout_sub_panel(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "BR Helper"
    bl_idname = "FILE_PT_br_helper_fout_sub_panel"
    bl_label = "Output Name parts"
    bl_parent_id = "FILE_PT_br_helper_fout_list"

    @classmethod
    def poll(cls, context):
        props = context.window_manager.br_helper_pg
        prefs = bpy.context.preferences.addons["batch render helper"].preferences
        return prefs.view_mode == 'UI_List'

    def draw_header_preset(self, _context):
        FILE_PT_br_helper_presets.draw_panel_header(self.layout)

    def draw(self, context):
        props = context.window_manager.br_helper_pg
        layout = self.layout
        box = layout.box()
        col = box.column(align=True)
        row = col.row()
        row.prop(props, "op_fname_enum", text="")
        row = layout.row()
        is_sortable = len(props.op_fname_parts) > 1
        rows = 3
        if is_sortable:
            rows = 5
        row = layout.row()
        row.template_list("FILE_UL_slots", "", props, "op_fname_parts", props, "act_fname_idx", rows=rows)
        col = row.column(align=True)
        add_part = col.operator("file.br_helper_fname_ops", icon='ADD', text="")
        add_part.item = props.op_fname_enum
        add_part.operation_type = "add_item"
        if props.op_fname_parts:
            del_act = col.operator("file.br_helper_fname_ops", icon='REMOVE', text="")
            del_act.operation_type = "del_act"
            del_act.idx = props.act_fname_idx
        if is_sortable:
            col.separator()
            move_up = col.operator("file.br_helper_fname_ops", icon='TRIA_UP', text="")
            move_up.operation_type = "move_up"
            move_up.idx = props.act_fname_idx
            move_dn = col.operator("file.br_helper_fname_ops", icon='TRIA_DOWN', text="")
            move_dn.operation_type = "move_dn"
            move_dn.idx = props.act_fname_idx
        if len(props.op_fname_parts):
            me = props.op_fname_parts[props.act_fname_idx].op_fname
            if props.op_fname_parts[props.act_fname_idx].eval_path and props.op_fname_parts[props.act_fname_idx].op_fname:
                try:
                    me = f"{eval(props.op_fname_parts[props.act_fname_idx].op_fname)}"
                except NameError:
                    me = "< can not evaluate >"
                    props.op_fname_parts[props.act_fname_idx].eval_path = False
                except SyntaxError:
                    me = "< can not evaluate >"
                    props.op_fname_parts[props.act_fname_idx].eval_path = False
            elif props.op_fname_parts[props.act_fname_idx].eval_path and not props.op_fname_parts[props.act_fname_idx].op_fname:
                me = "< nothing to evaluate >"
            box = layout.box()
            col = box.column()
            row = col.row()
            split = row.split(factor=0.8)
            col = split.column()
            col.label(text=me)
            split = split.split()
            col = split.column()
            col.prop(props.op_fname_parts[props.act_fname_idx], "eval_path", text="Eval")


class FILE_PT_br_helper_op_operators(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "BR Helper"
    bl_idname = "FILE_PT_br_helper_op_operators"
    bl_label = "Output operators"
    bl_parent_id = "FILE_PT_br_helper_main"

    def draw(self, context):
        layout = self.layout
        box = layout.box()
        col = box.column(align=True)
        op_test_mode = col.operator("file.br_helper_test_out", text="Test Output")
        op_test_mode.test_mode = True
        op_test_mode = col.operator("file.br_helper_test_out", text="Render")
        op_test_mode.test_mode = False
        col.operator("file.br_helper_cmd_out", text="Gen Batch File commands")


classes = [
    FILE_PT_br_helper_presets,
    FILE_PT_br_helper_main,
    FILE_PT_br_helper_scns_classic,
    FILE_PT_br_helper_fout_classic,
    FILE_UL_slots,
    FILE_PT_br_helper_scns_list,
    FILE_PT_br_helper_scn_sub_panel,
    FILE_PT_br_helper_fout_list,
    FILE_PT_br_helper_fout_sub_panel,
    FILE_PT_br_helper_op_operators,
    ]


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)

if __name__ == "__main__":
    register()
