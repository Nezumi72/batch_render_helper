import bpy


class FILE_PT_br_helper_main(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "BR Helper"
    bl_idname = "FILE_PT_br_helper_main"
    bl_label = "Batch Render Helper"

    def draw(self, context):
        pass


class FILE_PT_br_helper_loop_options(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "BR Helper"
    bl_idname = "FILE_PT_br_helper_loop_options"
    bl_label = "Loop Controls"
    bl_parent_id = "FILE_PT_br_helper_main"

    def draw(self, context):
        props = context.window_manager.br_helper_pg
        layout = self.layout
        box = layout.box()
        col = box.column(align=True)
        row = col.row()
        add_scn = row.operator("file.br_helper_add_scenes", text="Add Current Scene")
        add_scn.all_scenes = False
        add_scn = row.operator("file.br_helper_add_scenes", text="Add All Scenes")
        add_scn.all_scenes = True
        box = layout.box()
        col = box.column(align=True)
        row = col.row()
        row.label(text="Scene Name")
        row.label(text="All Frames")
        row.label(text="Remove Scene")
        for i, details in enumerate(props.loops):
            box = layout.box()
            col = box.column(align=True)
            row = col.row()
            if details.expand_loop_ctrl:
                row.prop(details, 'expand_loop_ctrl', text='', icon='DOWNARROW_HLT')
            else:
                row.prop(details, 'expand_loop_ctrl', text='', icon='RIGHTARROW')
            row.label(text=details.scn_ptr.name)
            move = row.operator(
                'file.br_helper_move', text='', icon='TRIA_UP')
            move.idx = i
            move.up = True
            move.loop = True
            move = row.operator(
                'file.br_helper_move', text='', icon='TRIA_DOWN')
            move.idx = i
            move.up = False
            move.loop = True
            del_item = row.operator(
                'file.br_helper_del_item', text='', icon='X')
            del_item.idx = i
            del_item.loop = True
            if details.expand_loop_ctrl:
                row = col.row()
                row.prop(details.scn_ptr, "frame_start", text="Start")
                row.prop(details.scn_ptr, "frame_end", text="End")
                row.prop(details.scn_ptr, "frame_step", text="Step")


class FILE_PT_br_helper_fout(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "BR Helper"
    bl_idname = "FILE_PT_br_helper_fout"
    bl_label = "Output File details"
    bl_parent_id = "FILE_PT_br_helper_main"

    def draw(self, context):
        props = context.window_manager.br_helper_pg
        layout = self.layout
        box = layout.box()
        col = box.column(align=True)
        col.prop(props, "op_dir")
        col.prop(props, "fname_sep", text="Separator")
        col.prop(props, "frame_cnt_leading", text="Frame leading 0's")
        box = layout.box()
        col = box.column(align=True)
        col.operator("file.br_helper_add_fname_part")
        for i, details in enumerate(props.op_fname_parts):
            box = layout.box()
            col = box.column(align=True)
            row = col.row()
            if details.expand_eval:
                row.prop(details, 'expand_eval', text='', icon='DOWNARROW_HLT')
            else:
                row.prop(details, 'expand_eval', text='', icon='RIGHTARROW')
            row.prop(details, 'op_fname', text='')
            row.prop(details, 'eval_path', text='')
            move = row.operator(
                'file.br_helper_move', text='', icon='TRIA_UP')
            move.idx = i
            move.up = True
            move.loop = False
            move = row.operator(
                'file.br_helper_move', text='', icon='TRIA_DOWN')
            move.idx = i
            move.up = False
            move.loop = False
            del_item = row.operator(
                'file.br_helper_del_item', text='', icon='X')
            del_item.idx = i
            del_item.loop = True
            me = ""
            if details.eval_path and details.op_fname:
                try:
                    me = f"{eval(details.op_fname)}"
                except NameError:
                    me = "< can not evaluate >"
                    details.eval_path = False
            elif details.eval_path and not details.op_fname:
                me = "< nothing to evaluate >"
            if details.expand_eval:
                col.label(text=me)


class FILE_PT_br_helper_op_operators(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "BR Helper"
    bl_idname = "FILE_PT_br_helper_op_operators"
    bl_label = "Output operators"
    bl_parent_id = "FILE_PT_br_helper_main"

    def draw(self, context):
        layout = self.layout
        box = layout.box()
        col = box.column(align=True)
        op_test_mode = col.operator("file.br_helper_test_out", text="Test Output")
        op_test_mode.test_mode = True
        op_test_mode = col.operator("file.br_helper_test_out", text="Render")
        op_test_mode.test_mode = False


classes = [
    FILE_PT_br_helper_main,
    FILE_PT_br_helper_loop_options,
    FILE_PT_br_helper_fout,
    FILE_PT_br_helper_op_operators,
    ]


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)

if __name__ == "__main__":
    register()
