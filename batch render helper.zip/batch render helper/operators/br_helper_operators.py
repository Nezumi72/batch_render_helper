import bpy
import os


class FILE_OT_br_helper_add_scene(bpy.types.Operator):
    bl_idname = 'file.br_helper_add_scene'
    bl_label = "Add scene to render"

    def execute(self, context):
        print(f'{self.bl_idname} button pressed')
        props = context.window_manager.br_helper_pg
        me = props.loops.add()
        me.name = 'loop' + str(len(props.loops)-1)
        me.scn_ptr = context.scene
        return {'FINISHED'}


class FILE_OT_br_helper_add_all_scenes(bpy.types.Operator):
    bl_idname = 'file.br_helper_add_all_scenes'
    bl_label = "Add all scenes to render"

    def execute(self, context):
        print(f'{self.bl_idname} button pressed')
        props = context.window_manager.br_helper_pg
        for scn in bpy.data.scenes:
            me = props.loops.add()
            me.name = 'loop' + str(len(props.loops)-1)
            me.scn_ptr = scn
        return {'FINISHED'}


class FILE_OT_br_helper_del_scene(bpy.types.Operator):
    bl_idname = 'file.br_helper_del_scene'
    bl_label = "Remove loop from render"

    idx: bpy.props.IntProperty()

    def execute(self, context):
        print(f'{self.bl_idname} button pressed')
        props = context.window_manager.br_helper_pg
        props.loops.remove(self.idx)
        return {'FINISHED'}


class FILE_OT_br_helper_add_fname_part(bpy.types.Operator):
    bl_idname = 'file.br_helper_add_fname_part'
    bl_label = "Add part to output file name"

    def execute(self, context):
        print(f'{self.bl_idname} button pressed')
        props = context.window_manager.br_helper_pg
        me = props.op_fname_parts.add()
        me.name = 'fname' + str(len(props.op_fname_parts)-1)
        me.op_fname = ""
        return {'FINISHED'}


class FILE_OT_br_helper_del_fname_part(bpy.types.Operator):
    bl_idname = 'file.br_helper_del_fname_part'
    bl_label = "Remove part of output file name"

    idx: bpy.props.IntProperty()

    def execute(self, context):
        print(f'{self.bl_idname} button pressed')
        props = context.window_manager.br_helper_pg
        props.op_fname_parts.remove(self.idx)
        return {'FINISHED'}


class FILE_OT_br_helper_test_out(bpy.types.Operator):
    bl_idname = 'file.br_helper_test_out'
    bl_label = "Test Output"

    test_mode: bpy.props.BoolProperty()

    def execute(self, context):
        print(f'{self.bl_idname} button pressed')
        file_formats = {
            'BMP': "bmp",
            'IRIS': "rgb",
            'PNG': "png",
            'JPEG': "jpg",
            'JPEG2000': "jp2",
            'TARGA': "tga",
            'TARGA_RAW': "tga",
            'CINEON': "cin",
            'DPX': "dpx",
            'OPEN_EXR_MULTILAYER': "exr",
            'OPEN_EXR': "exr",
            'HDR': "hdr",
            'TIFF': "tif"
            }
        props = context.window_manager.br_helper_pg
        txtname = 'br_helper_test'
        if txtname not in bpy.data.texts:
            ntxt = bpy.data.texts.new(txtname)
        else:
            ntxt = bpy.data.texts[txtname]
            if self.test_mode:
                ntxt.clear()
        for i, l_details in enumerate(props.loops):
            scn = l_details.scn_ptr
            bpy.context.window.scene = scn
            for frm in range(scn.frame_start, scn.frame_end+1, scn.frame_step):
                scn.frame_set(frm)
                txt_string = ""
                for i, f_details in enumerate(props.op_fname_parts):
                    if f_details.eval_path:
                        sample = f_details.op_fname
                        me2 = sample.split(sep='.')
                        me = []
                        for txt in me2:
                            if not txt[0].isdigit():
                                me.append(txt)
                            else:
                                me[-1] += '_'+txt
                        if me[2].startswith("scenes"):
                            if len(me) == 4:
                                conv = f"bpy.context.scene.{me[-1]}"
                            else:
                                cmd_end = '.'.join(me[3:])
                                conv = f"bpy.context.scene.{cmd_end}"
                            txt_string += str(eval(conv))
                        else:  # not a scene property but still evaluated
                            txt_string += str(eval(f_details.op_fname))
                    else:
                        txt_string += f_details.op_fname
                    if i < len(props.op_fname_parts)-1:
                        txt_string += props.fname_sep
                if len(txt_string):
                    txt_string += f"{props.fname_sep}"
                txt_string += f"{scn.frame_current}"
                txt_string += f".{file_formats.get(scn.render.image_settings.file_format)}"
                if self.test_mode:
                    ntxt.write(f"{os.path.join(props.op_dir, txt_string)}\n")
                else:
                    scn.render.filepath = os.path.join(props.op_dir, txt_string)
                    bpy.ops.render.render(animation=False, write_still=True, use_viewport=False)
        return {'FINISHED'}


classes = [
    FILE_OT_br_helper_add_scene,
    FILE_OT_br_helper_add_all_scenes,
    FILE_OT_br_helper_del_scene,
    FILE_OT_br_helper_add_fname_part,
    FILE_OT_br_helper_del_fname_part,
    FILE_OT_br_helper_test_out,
    ]


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)

if __name__ == "__main__":
    register()
