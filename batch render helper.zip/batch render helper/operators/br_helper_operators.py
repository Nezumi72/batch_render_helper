import bpy
import os
from bl_operators.presets import AddPresetBase


class FILE_OT_br_helper_cmd_out(bpy.types.Operator):
    bl_idname = 'file.br_helper_cmd_out'
    bl_label = "Batch Commands"

    def execute(self, context):
        print(f'{self.bl_idname}')
        props = context.window_manager.br_helper_pg
        txtname = 'br_helper_cmd'
        if txtname not in bpy.data.texts:
            ntxt = bpy.data.texts.new(txtname)
        else:
            ntxt = bpy.data.texts[txtname]
            ntxt.clear()
        # find blender directory and add change directory command line
        # to avoid necessity of blender path in os environment variables
        b_dir = os.path.dirname(bpy.app.binary_path)
        ntxt.write(f"cd {b_dir}\n")
        # create command lines to render
        b_file = os.path.basename(bpy.app.binary_path)
        f_path = bpy.context.blend_data.filepath
        o_dir = props.op_dir
        for scn in props.loops:
            context.window.scene = scn.scn_ptr
            for frm in range(context.scene.frame_start, context.scene.frame_end+1, context.scene.frame_step):
                context.window.scene.frame_set(frm)
                ntxt.write(f"{b_file}")  # blender executable
                ntxt.write(f" -b")  # use background render
                ntxt.write(f" {f_path}")  # this blend file
                ntxt.write(f" -S {scn.scn_ptr.name}")  # render this scene
                ntxt.write(f" -o")  # use output directory
                ntxt.write(f" {o_dir}")  # output directory
                f_out = []
                for n_part in props.op_fname_parts:
                    if n_part.eval_path:
                        me = (n_part.op_fname)
                        if "frame_current" in me:
                            me = "#"*props.frame_cnt_leading
                            f_out.append(f"{me}")
                        elif "filepath" in me:
                            me = os.path.basename(eval(me)).split(".")[0]
                            f_out.append(f"{me}")
                        else:
                            f_out.append(f"{eval(me)}")
                    else:
                        f_out.append(f"{n_part.op_fname}")
                name_out = props.fname_sep.join(f_out)
                ntxt.write(f"{name_out}")  # assembled output file name
                ntxt.write(f" -f {frm} \n")  # frame to render
        return {'FINISHED'}


class FILE_MT_br_helper_presets(bpy.types.Menu):
    bl_label = 'BR Helper Presets'
    preset_subdir = 'BR_Helper'
    preset_operator = 'script.execute_preset'
    draw = bpy.types.Menu.draw_preset


class FILE_OT_br_helper_preset_add(AddPresetBase, bpy.types.Operator):
    bl_idname = 'br_helper.add_preset'
    bl_label = 'Add filenaming preset'
    preset_menu = 'FILE_MT_br_helper_presets'

    # Common variable used for all preset values
    preset_defines = [
        'props = bpy.context.window_manager.br_helper_pg',
    ]

    # Properties to store in the preset
    preset_values = [
        'props.op_fname_parts',
    ]

    # Directory to store the presets
    preset_subdir = 'BR_Helper'


class FILE_OT_br_helper_fname_ops(bpy.types.Operator):
    bl_idname = 'file.br_helper_fname_ops'
    bl_label = "FName Ops"

    operation_type: bpy.props.EnumProperty(
        name="operation_type",
        items=(
            ("add_item", "add_item", "add_item"),
            ("del_act", "del_act", "Remove Selected from list"),
            ("move_up", "move_up", "Move Selected up"),
            ("move_dn", "move_dn", "Move Selected down"),
        ),
        description="",
        default="del_act",
    )
    idx: bpy.props.IntProperty(default=-1)
    item: bpy.props.StringProperty()

    def execute(self, context):
        if self.idx > -1:
            print(f'{self.bl_idname}:{self.operation_type}:{self.item}:{self.idx}')
        else:
            print(f'{self.bl_idname}:{self.operation_type}:{self.item}')
        props = context.window_manager.br_helper_pg
        if self.operation_type == "add_item":
            me = props.op_fname_parts.add()
            me.name = 'fname' + str(len(props.op_fname_parts)-1)
            me.op_fname = self.item
            if self.item != "text":
                me.eval_path = True
        elif self.operation_type == "del_act":
            props.op_fname_parts.remove(self.idx)
            props.act_fname_idx = min(max(0, self.idx - 1), len(props.op_fname_parts) - 1)
        elif self.operation_type == "move_up" and self.idx > 0:
            props.act_fname_idx = self.idx - 1
            # rename to maintain order for preset imports
            props.op_fname_parts[self.idx].name = 'fname' + str(self.idx-1)
            props.op_fname_parts[self.idx-1].name = 'fname' + str(self.idx)
            props.op_fname_parts.move(self.idx, self.idx-1)
        elif self.operation_type == "move_dn" and self.idx < len(props.op_fname_parts)-1:
            props.act_fname_idx = self.idx + 1
            # rename to maintain order for preset imports
            props.op_fname_parts[self.idx].name = 'fname' + str(self.idx+1)
            props.op_fname_parts[self.idx+1].name = 'fname' + str(self.idx)
            props.op_fname_parts.move(self.idx, self.idx+1)
        return {'FINISHED'}


class FILE_OT_br_helper_scene_ops(bpy.types.Operator):
    bl_idname = 'file.br_helper_scn_ops'
    bl_label = "Scene Ops"

    operation_type: bpy.props.EnumProperty(
        name="operation_type",
        items=(
            ("add_current", "add_current", "Add current scene to list"),
            ("add_all", "add_all", "Add all scenes to list"),
            ("del_act", "del_act", "Remove Selected scene from list"),
            ("move_up", "move_up", "Move Selected scene up"),
            ("move_dn", "move_dn", "Move Selected scene down"),
        ),
        description="",
        default="add_current",
    )
    idx: bpy.props.IntProperty(default=-1)

    def execute(self, context):
        if self.idx > -1:
            print(f'{self.bl_idname}:{self.operation_type}:{self.idx}')
        else:
            print(f'{self.bl_idname}:{self.operation_type}')
        props = context.window_manager.br_helper_pg
        if self.operation_type in ["add_current", "add_all"]:
            current_scns = [item.scn_ptr for item in props.loops]
            if self.operation_type == "add_all":
                scns = bpy.data.scenes
            else:
                scns = [context.scene]
            for scn in scns:
                # skip duplicating scenes when adding
                if scn in current_scns:
                    continue
                me = props.loops.add()
                me.name = scn.name
                me.scn_ptr = scn
        elif self.operation_type == "del_act":
            props.loops.remove(self.idx)
            props.act_scn_idx = min(max(0, self.idx - 1), len(props.loops) - 1)
        elif self.operation_type == "move_up" and self.idx > 0:
            props.act_scn_idx = self.idx - 1
            props.loops.move(self.idx, self.idx-1)
        elif self.operation_type == "move_dn" and self.idx < len(props.loops)-1:
            props.act_scn_idx = self.idx + 1
            props.loops.move(self.idx, self.idx+1)
        return {'FINISHED'}


class FILE_OT_br_helper_test_out(bpy.types.Operator):
    bl_idname = 'file.br_helper_test_out'
    bl_label = "Test Output"

    test_mode: bpy.props.BoolProperty()

    def execute(self, context):
        print(f'{self.bl_idname}:{self.test_mode}')
        file_formats = {
            'BMP': "bmp",
            'IRIS': "rgb",
            'PNG': "png",
            'JPEG': "jpg",
            'JPEG2000': "jp2",
            'TARGA': "tga",
            'TARGA_RAW': "tga",
            'CINEON': "cin",
            'DPX': "dpx",
            'OPEN_EXR_MULTILAYER': "exr",
            'OPEN_EXR': "exr",
            'HDR': "hdr",
            'TIFF': "tif"
            }
        props = context.window_manager.br_helper_pg
        txtname = 'br_helper_test'
        if txtname not in bpy.data.texts:
            ntxt = bpy.data.texts.new(txtname)
        else:
            ntxt = bpy.data.texts[txtname]
            if self.test_mode:
                ntxt.clear()
        for i, l_details in enumerate(props.loops):
            scn = l_details.scn_ptr
            bpy.context.window.scene = scn
            for frm in range(scn.frame_start, scn.frame_end+1, scn.frame_step):
                scn.frame_set(frm)
                txt_string = ""
                for i, f_details in enumerate(props.op_fname_parts):
                    if f_details.op_fname.endswith('.frame_current'):
                        txt_string += f"%0{props.frame_cnt_leading}d" % (scn.frame_current)
                        if i < len(props.op_fname_parts)-1:
                            txt_string += props.fname_sep
                        continue
                    if f_details.op_fname.startswith('bpy.path'):
                        txt_string += bpy.path.basename(bpy.context.blend_data.filepath).split(".blend")[0]
                        if i < len(props.op_fname_parts)-1:
                            txt_string += props.fname_sep
                        continue
                    if f_details.eval_path:
                        sample = f_details.op_fname
                        me2 = sample.split(sep='.')
                        me = []
                        for txt in me2:
                            if not txt[0].isdigit():
                                me.append(txt)
                            else:
                                me[-1] += '_'+txt
                        if me[2].startswith("scenes"):
                            if len(me) == 4:
                                conv = f"bpy.context.scene.{me[-1]}"
                            else:
                                cmd_end = '.'.join(me[3:])
                                conv = f"bpy.context.scene.{cmd_end}"
                            txt_string += str(eval(conv))
                        else:  # not a scene property but still evaluated
                            txt_string += str(eval(f_details.op_fname))
                    else:
                        txt_string += f_details.op_fname
                    if i < len(props.op_fname_parts)-1:
                        txt_string += props.fname_sep
                txt_string += f".{file_formats.get(scn.render.image_settings.file_format)}"
                if self.test_mode:
                    ntxt.write(f"{os.path.join(props.op_dir, txt_string)}\n")
                else:
                    scn.render.filepath = os.path.join(props.op_dir, txt_string)
                    bpy.ops.render.render(animation=False, write_still=True, use_viewport=False)
        return {'FINISHED'}


classes = [
    FILE_OT_br_helper_cmd_out,
    FILE_MT_br_helper_presets,
    FILE_OT_br_helper_preset_add,
    FILE_OT_br_helper_scene_ops,
    FILE_OT_br_helper_fname_ops,
    FILE_OT_br_helper_test_out,
    ]


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)

if __name__ == "__main__":
    register()
